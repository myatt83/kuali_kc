﻿
var MAIN_HELP_PAGE = "default.htm";
var g_d2hContextIds = new Array();
